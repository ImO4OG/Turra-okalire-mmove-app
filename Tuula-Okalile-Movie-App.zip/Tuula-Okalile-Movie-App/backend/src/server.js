import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();
const app = express();
const PORT = process.env.PORT || 5000;
const allowedOrigins = (process.env.FRONTEND_URL || 'http://localhost:5173')
  .split(',').map((origin) => origin.trim()).filter(Boolean);

app.use(cors({ origin(origin, callback) {
  // Allow server-to-server / local tooling requests without an Origin header.
  if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
  return callback(new Error('Origin is not allowed by CORS'));
} }));
app.use(express.json());

app.get('/', (_req, res) => res.json({ name: 'Tuula Okalile Moviebox API', status: 'ok' }));
app.get('/health', (_req, res) => res.json({ status: 'healthy' }));

app.use('/api/tmdb', async (req, res) => {
  if (!process.env.TMDB_TOKEN || process.env.TMDB_TOKEN === 'your_tmdb_read_access_token_here') {
    return res.status(500).json({ error: 'TMDB_TOKEN is missing. Configure it in the backend environment.' });
  }
  const apiPath = req.path.replace(/^\/+/, '');
  const target = new URL(`https://api.themoviedb.org/3/${apiPath}`);
  for (const [key, value] of Object.entries(req.query)) {
    if (Array.isArray(value)) value.forEach((item) => target.searchParams.append(key, String(item)));
    else if (value !== undefined) target.searchParams.set(key, String(value));
  }
  try {
    const response = await fetch(target, {
      headers: { Authorization: `Bearer ${process.env.TMDB_TOKEN}`, Accept: 'application/json' },
    });
    const body = await response.text();
    res.set('Cache-Control', 'public, max-age=60');
    res.status(response.status).type('application/json').send(body);
  } catch (error) {
    console.error('TMDB proxy error:', error.message);
    res.status(502).json({ error: 'Could not reach the movie data service. Please try again.' });
  }
});

app.use((err, _req, res, _next) => {
  if (err.message === 'Origin is not allowed by CORS') return res.status(403).json({ error: err.message });
  console.error(err);
  res.status(500).json({ error: 'Unexpected server error' });
});

app.listen(PORT, () => console.log(`Tuula Okalile backend listening on port ${PORT}`));
